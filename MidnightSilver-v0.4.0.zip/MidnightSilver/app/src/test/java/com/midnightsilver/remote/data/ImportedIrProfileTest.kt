package com.midnightsilver.remote.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Test
import org.json.JSONObject

class ImportedIrProfileTest {
    private fun validProfile(): String = JSONObject().apply {
        put("schemaVersion", 1)
        put("brandId", "ogeneral")
        put("modelLabel", "O General test profile")
        put("carrierFrequencyHz", 38000)
        put("commands", org.json.JSONArray().put(JSONObject().apply {
            put("state", JSONObject().apply {
                put("power", true); put("temperature", 24); put("celsius", true)
                put("mode", "COOL"); put("fan", "AUTO"); put("swing", false)
                put("eco", false); put("sleep", false)
            })
            put("durationsMicros", org.json.JSONArray(listOf(9000, 4500, 560, 560)))
        }))
    }.toString()

    @Test fun importedProfilesAreNeverAutoConfirmed() {
        val profile = ImportedIrProfile.parse(validProfile())
        assertFalse(profile.userConfirmed)
        assertEquals("ogeneral", profile.brandId)
        assertEquals(38000, profile.carrierFrequencyHz)
        assertEquals(1, profile.frames.size)
    }

    @Test fun profileRoundTripPreservesFrames() {
        val first = ImportedIrProfile.parse(validProfile())
        val second = ImportedIrProfile.parse(first.toJson().toString())
        assertEquals(first.frames, second.frames)
        assertEquals(first.modelLabel, second.modelLabel)
    }

    @Test fun invalidOddLengthFrameIsRejected() {
        val broken = JSONObject(validProfile())
        val commands = broken.getJSONArray("commands")
        commands.getJSONObject(0).put("durationsMicros", org.json.JSONArray(listOf(9000, 4500, 560)))
        assertThrows(IllegalArgumentException::class.java) { ImportedIrProfile.parse(broken.toString()) }
    }

    @Test fun unsupportedCarrierIsRejected() {
        val broken = JSONObject(validProfile()).put("carrierFrequencyHz", 1000)
        assertThrows(IllegalArgumentException::class.java) { ImportedIrProfile.parse(broken.toString()) }
    }
}
