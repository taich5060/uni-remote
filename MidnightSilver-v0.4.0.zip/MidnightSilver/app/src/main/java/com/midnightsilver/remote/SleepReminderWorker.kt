package com.midnightsilver.remote

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

/** A reminder only. It never claims to switch the AC off without a verified command profile. */
class SleepReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val deviceName = inputData.getString("device_name") ?: "Your AC"
        val deviceId = inputData.getString("device_id") ?: "default"
        applicationContext.getSharedPreferences("midnight_silver", Context.MODE_PRIVATE)
            .edit().remove("sleep_timer_$deviceId").apply()
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "AC sleep reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val intent = applicationContext.packageManager.getLaunchIntentForPackage(applicationContext.packageName)
        val pendingIntent = intent?.let {
            PendingIntent.getActivity(applicationContext, 1001, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("AC sleep timer finished")
            .setContentText("Check $deviceName and switch it off if needed.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Your reminder for $deviceName has finished. This is a reminder only; the app has not sent an automatic power-off command."))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        return try {
            NotificationManagerCompat.from(applicationContext).notify(NOTIFICATION_ID + (deviceId.hashCode() and 0x0FFF), notification)
            Result.success()
        } catch (_: SecurityException) {
            // Notifications are optional and may be disabled by the user.
            Result.success()
        }
    }

    companion object {
        private const val CHANNEL_ID = "ac_sleep_reminders"
        private const val NOTIFICATION_ID = 4107
    }
}
