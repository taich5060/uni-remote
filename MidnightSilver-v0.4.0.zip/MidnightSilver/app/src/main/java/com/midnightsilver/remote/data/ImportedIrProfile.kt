package com.midnightsilver.remote.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ImportedStateFrame(val state: AcState, val durationsMicros: List<Int>)

data class ImportedIrProfile(
    val id: String = UUID.randomUUID().toString(),
    val brandId: String,
    val modelLabel: String,
    val carrierFrequencyHz: Int,
    val frames: List<ImportedStateFrame>,
    val userConfirmed: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("schemaVersion", 1); put("id", id); put("brandId", brandId)
        put("modelLabel", modelLabel); put("carrierFrequencyHz", carrierFrequencyHz)
        val commands = JSONArray()
        frames.forEach { frame ->
            val state = frame.state
            val stateJson = JSONObject().apply {
                put("power", state.power); put("temperature", state.temperature); put("celsius", state.celsius)
                put("mode", state.mode.name); put("fan", state.fan.name); put("swing", state.swing)
                put("eco", state.eco); put("sleep", state.sleep)
            }
            val durations = JSONArray().apply { frame.durationsMicros.forEach { put(it) } }
            commands.put(JSONObject().put("state", stateJson).put("durationsMicros", durations))
        }
        put("commands", commands)
    }

    companion object {
        /** Import format accepts raw timings, but never trusts an imported "verified" flag. */
        fun parse(raw: String): ImportedIrProfile {
            require(raw.length <= 2_000_000) { "Profile file is too large (maximum 2 MB)." }
            val root = JSONObject(raw)
            require(root.optInt("schemaVersion", -1) == 1) { "Unsupported profile schema version." }
            val brandId = root.optString("brandId").trim()
            val model = root.optString("modelLabel").trim()
            val carrier = root.optInt("carrierFrequencyHz", 0)
            require(brandId.isNotBlank() && brandId.length <= 64) { "A valid brandId is required." }
            require(model.isNotBlank() && model.length <= 100) { "A model label is required." }
            require(carrier in 30_000..60_000) { "Carrier frequency must be between 30 kHz and 60 kHz." }
            val commands = root.optJSONArray("commands") ?: throw IllegalArgumentException("The profile has no commands array.")
            require(commands.length() in 1..100) { "A profile must contain between 1 and 100 state frames." }
            val frames = buildList {
                for (index in 0 until commands.length()) {
                    val command = commands.optJSONObject(index) ?: throw IllegalArgumentException("Command ${index + 1} is invalid.")
                    val json = command.optJSONObject("state") ?: throw IllegalArgumentException("Command ${index + 1} has no state.")
                    val celsius = json.optBoolean("celsius", true)
                    val temperature = json.optInt("temperature", if (celsius) 24 else 75)
                    require(temperature in (if (celsius) 16..30 else 61..86)) { "Command ${index + 1} has an out-of-range temperature." }
                    val mode = runCatching { AcMode.valueOf(json.optString("mode", "COOL")) }
                        .getOrElse { throw IllegalArgumentException("Command ${index + 1} has an unsupported mode.") }
                    val fan = runCatching { FanSpeed.valueOf(json.optString("fan", "AUTO")) }
                        .getOrElse { throw IllegalArgumentException("Command ${index + 1} has an unsupported fan speed.") }
                    val state = AcState(
                        power = json.optBoolean("power", false), temperature = temperature,
                        mode = mode, fan = fan,
                        swing = json.optBoolean("swing", false), celsius = celsius,
                        sleep = json.optBoolean("sleep", false), eco = json.optBoolean("eco", false)
                    )
                    val timings = command.optJSONArray("durationsMicros") ?: throw IllegalArgumentException("Command ${index + 1} has no raw timings.")
                    require(timings.length() in 2..2048 && timings.length() % 2 == 0) { "Command ${index + 1} must have an even number of 2–2048 timings." }
                    val durations = buildList {
                        var total = 0L
                        for (j in 0 until timings.length()) {
                            val value = timings.optInt(j, -1)
                            require(value in 1..100_000) { "Command ${index + 1} contains an invalid timing." }
                            total += value
                            require(total <= 1_000_000L) { "Command ${index + 1} exceeds the 1-second frame safety limit." }
                            add(value)
                        }
                    }
                    add(ImportedStateFrame(state, durations))
                }
            }
            val id = root.optString("id").takeIf { it.isNotBlank() && it.length <= 100 } ?: UUID.randomUUID().toString()
            return ImportedIrProfile(id, brandId, model, carrier, frames, userConfirmed = false)
        }
    }
}
