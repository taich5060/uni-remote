package com.midnightsilver.remote.ir

import com.midnightsilver.remote.data.AcState
import com.midnightsilver.remote.data.IrProfile

/** A complete AC frame; most AC remotes transmit state rather than isolated button codes. */
data class EncodedAcFrame(val carrierFrequencyHz: Int, val durationsMicros: IntArray)

/** Implement this only for a protocol whose framing and state encoding have been verified. */
interface AcProtocolEncoder {
    val protocolId: String
    fun encode(state: AcState): EncodedAcFrame
}

sealed interface AcCommandResult {
    data object NoVerifiedProfile : AcCommandResult
    data object NoEncoder : AcCommandResult
    data class Transmitted(val status: IrStatus) : AcCommandResult
    data class Rejected(val reason: String) : AcCommandResult
}

/** Registry intentionally starts empty. Adding a brand name is not the same as verifying its IR protocol. */
class IrProfileRegistry(encoders: List<AcProtocolEncoder> = emptyList()) {
    private val byId = encoders.associateBy { it.protocolId }
    fun encoderFor(profile: IrProfile): AcProtocolEncoder? =
        if (profile.verified) byId[profile.protocolName] else null
}

class AcCommandService(
    private val transmitter: IrTransmitter,
    private val registry: IrProfileRegistry = IrProfileRegistry()
) {
    fun send(state: AcState, profile: IrProfile?): AcCommandResult {
        if (profile == null || !profile.verified) return AcCommandResult.NoVerifiedProfile
        val encoder = registry.encoderFor(profile) ?: return AcCommandResult.NoEncoder
        val frame = try {
            encoder.encode(state)
        } catch (e: Exception) {
            return AcCommandResult.Rejected(e.message ?: "Could not encode the AC state.")
        }
        if (frame.carrierFrequencyHz <= 0) return AcCommandResult.Rejected("Invalid carrier frequency.")
        return AcCommandResult.Transmitted(transmitter.transmit(frame.carrierFrequencyHz, frame.durationsMicros))
    }
}
