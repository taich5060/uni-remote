package com.midnightsilver.remote.data

import java.util.UUID

data class AcDevice(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val brandId: String = "ogeneral",
    val state: AcState = AcState(),
    val profileId: String? = null
)

object DeviceDefaults {
    fun primary() = AcDevice(name = "Living room AC", brandId = "ogeneral")
}
