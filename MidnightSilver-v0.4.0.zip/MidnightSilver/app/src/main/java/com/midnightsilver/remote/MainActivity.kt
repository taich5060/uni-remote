package com.midnightsilver.remote

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.work.*
import java.util.concurrent.TimeUnit
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Canvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.midnightsilver.remote.data.*
import com.midnightsilver.remote.ir.*
import com.midnightsilver.remote.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ir = IrTransmitter(this)
        val store = LocalStore(this)
        setContent { MidnightSilverTheme { MidnightApp(ir, store) } }
    }
}

private fun scheduleSleepReminder(context: android.content.Context, minutes: Int, deviceName: String, deviceId: String) {
    val workManager = WorkManager.getInstance(context)
    val uniqueName = "sleep-reminder-$deviceId"
    workManager.cancelUniqueWork(uniqueName)
    if (minutes <= 0) return
    val request = OneTimeWorkRequestBuilder<SleepReminderWorker>()
        .setInitialDelay(minutes.toLong(), TimeUnit.MINUTES)
        .setInputData(workDataOf("device_name" to deviceName, "device_id" to deviceId))
        .addTag("sleep-reminder")
        .build()
    workManager.enqueueUniqueWork(uniqueName, ExistingWorkPolicy.REPLACE, request)
}

private enum class Tab(val label: String) { REMOTE("Remote"), DEVICES("Devices"), PROFILES("IR Profiles"), FAVORITES("Presets"), SETTINGS("Settings") }

@Composable
private fun MidnightApp(ir: IrTransmitter, store: LocalStore) {
    var tab by remember { mutableStateOf(Tab.REMOTE) }
    var devices by remember { mutableStateOf(store.loadDevices()) }
    var selectedDeviceId by remember { mutableStateOf(devices.first().id) }
    var state by remember { mutableStateOf(devices.first().state) }
    val selectedDevice = devices.firstOrNull { it.id == selectedDeviceId } ?: devices.first()
    val brandId = selectedDevice.brandId
    var favorites by remember { mutableStateOf(store.loadFavorites()) }
    var profiles by remember { mutableStateOf(store.loadImportedProfiles()) }
    var testedProfileIds by remember { mutableStateOf(emptySet<String>()) }
    val profileService = remember(ir) { ImportedProfileService(ir) }
    var notice by remember { mutableStateOf("No tested AC profile selected. Controls are in preview mode.") }
    var timerMinutesByDevice by remember {
        mutableStateOf(devices.mapNotNull { device ->
            store.loadTimerRemainingMinutes(device.id).takeIf { it > 0 }?.let { device.id to it }
        }.toMap())
    }
    val timerMinutes = timerMinutesByDevice[selectedDeviceId] ?: 0
    val status = remember { ir.status() }
    val context = LocalContext.current
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val importProfileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val result = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalArgumentException("Could not open the selected file.")
            }.mapCatching { ImportedIrProfile.parse(it) }
            result.onSuccess { imported ->
                profiles = (profiles.filterNot { it.id == imported.id } + imported)
                notice = "Imported ${imported.modelLabel}. Test it against the actual AC before confirming it."
            }.onFailure { error -> notice = "Profile import failed: ${error.message ?: "Invalid file"}" }
        }
    }

    LaunchedEffect(state, selectedDeviceId) {
        devices = devices.map { if (it.id == selectedDeviceId) it.copy(state = state) else it }
    }
    LaunchedEffect(devices) { store.saveDevices(devices) }
    LaunchedEffect(favorites) { store.saveFavorites(favorites) }
    LaunchedEffect(profiles) { store.saveImportedProfiles(profiles) }

    Scaffold(
        containerColor = Midnight,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF10141B), contentColor = Silver) {
                Tab.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = tab == destination,
                        onClick = { tab = destination },
                        icon = { Icon(when (destination) {
                            Tab.REMOTE -> Icons.Rounded.Tune
                            Tab.DEVICES -> Icons.Rounded.Devices
                            Tab.PROFILES -> Icons.Rounded.Code
                            Tab.FAVORITES -> Icons.Rounded.Bookmark
                            Tab.SETTINGS -> Icons.Rounded.Settings
                        }, contentDescription = destination.label) },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.padding(padding),
            transitionSpec = { (fadeIn(spring(stiffness = 420f)) + scaleIn(initialScale = .985f)) togetherWith (fadeOut() + scaleOut(targetScale = .99f)) },
            label = "tab-transition"
        ) { page ->
            when (page) {
                Tab.REMOTE -> RemoteScreen(
                    state = state, update = { state = it; notice = "Settings updated locally. No verified IR profile is active." },
                    brandId = brandId, deviceName = selectedDevice.name, notice = notice, irStatus = status, timerMinutes = timerMinutes,
                    onOpenDevices = { tab = Tab.DEVICES },
                    onSend = {
                        when (val result = profileService.send(state, profiles.firstOrNull { it.id == selectedDevice.profileId })) {
                            ProfileSendResult.NoProfile -> notice = "No IR profile is assigned to this AC. Import and assign a compatible profile first."
                            ProfileSendResult.ProfileNotConfirmed -> notice = "This profile has not been confirmed against the actual AC yet. Test it in IR Profiles first."
                            ProfileSendResult.StateNotIncluded -> notice = "This exact combination is not included in the imported profile. Add a matching full-state frame."
                            is ProfileSendResult.Sent -> notice = when (val sent = result.status) {
                                IrStatus.Ready -> "Android accepted the IR frame. Check whether the AC responded; transmission alone cannot confirm reception."
                                IrStatus.NoEmitter -> "No IR emitter is available on this phone."
                                IrStatus.UnsupportedFrequency -> "This phone does not support the profile carrier frequency."
                                is IrStatus.Failed -> sent.reason
                            }
                        }
                    },
                    onTimer = {
                        timerMinutesByDevice = if (it > 0) timerMinutesByDevice + (selectedDeviceId to it) else timerMinutesByDevice - selectedDeviceId
                        store.saveTimerDeadline(selectedDeviceId, if (it > 0) System.currentTimeMillis() + it * 60_000L else null)
                        if (it > 0 && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        scheduleSleepReminder(context, it, selectedDevice.name, selectedDevice.id)
                    }, onSaveFavorite = { name ->
                        favorites = (favorites + FavoritePreset(name, state)).takeLast(12)
                    }
                )
                Tab.DEVICES -> DevicesScreen(
                    devices = devices,
                    profiles = profiles,
                    selectedDeviceId = selectedDeviceId,
                    onSelect = { device -> selectedDeviceId = device.id; state = device.state; tab = Tab.REMOTE },
                    onAdd = { name ->
                        val device = AcDevice(name = name, brandId = "ogeneral")
                        devices = devices + device
                        selectedDeviceId = device.id
                        state = device.state
                        notice = "${device.name} added. Choose its brand and a compatible IR profile."
                    },
                    onRename = { device, name -> devices = devices.map { if (it.id == device.id) it.copy(name = name) else it } },
                    onDelete = { device ->
                        if (devices.size > 1) {
                            devices = devices - device
                            if (selectedDeviceId == device.id) {
                                val next = devices.first()
                                selectedDeviceId = next.id
                                state = next.state
                            }
                        }
                    },
                    onBrand = { device, brand ->
                        devices = devices.map { if (it.id == device.id) it.copy(brandId = brand, profileId = null) else it }
                        notice = "Brand updated. Assign a matching imported profile when available."
                    },
                    onProfile = { device, profileId -> devices = devices.map { if (it.id == device.id) it.copy(profileId = profileId) else it } }
                )
                Tab.PROFILES -> ProfilesScreen(
                    profiles = profiles,
                    testedProfileIds = testedProfileIds,
                    onImport = { importProfileLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                    onTest = { profile ->
                        val result = profileService.test(profile)
                        if (result == IrStatus.Ready) testedProfileIds = testedProfileIds + profile.id
                        notice = when (result) {
                            IrStatus.Ready -> "Android accepted a test frame. Check the actual AC. If it responded correctly, confirm this profile below."
                            IrStatus.NoEmitter -> "No IR emitter detected. A built-in IR transmitter is required."
                            IrStatus.UnsupportedFrequency -> "This phone does not support this profile's carrier frequency."
                            is IrStatus.Failed -> result.reason
                            null -> "No test frame is available."
                        }
                    },
                    onConfirm = { profile -> profiles = profiles.map { if (it.id == profile.id) it.copy(userConfirmed = true) else it }; notice = "Profile marked as user-tested. Only imported states will be transmitted." },
                    onDelete = { profile -> profiles = profiles - profile; testedProfileIds = testedProfileIds - profile.id; devices = devices.map { if (it.profileId == profile.id) it.copy(profileId = null) else it } }
                )
                Tab.FAVORITES -> FavoritesScreen(favorites, onApply = { state = it; tab = Tab.REMOTE; notice = "Preset loaded locally. IR transmission is not confirmed." }, onDelete = { favorites = favorites - it })
                Tab.SETTINGS -> SettingsScreen(status, ir.supportedCarrierRanges())
            }
        }
    }
}

@Composable
private fun RemoteScreen(
    state: AcState, update: (AcState) -> Unit, brandId: String, deviceName: String, notice: String,
    irStatus: IrStatus, timerMinutes: Int, onTimer: (Int) -> Unit, onSaveFavorite: (String) -> Unit,
    onSend: () -> Unit, onOpenDevices: () -> Unit
) {
    val brand = BrandCatalog.brands.firstOrNull { it.id == brandId } ?: BrandCatalog.brands.first()
    var showSaveDialog by remember { mutableStateOf(false) }
    var showTimerDialog by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("Comfort") }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(19.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MIDNIGHT SILVER", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.4.sp)
                    Text("Climate control", color = Silver, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(PanelRaised), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.AcUnit, null, tint = Accent, modifier = Modifier.size(22.dp))
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable(onClick = onOpenDevices).padding(15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(PanelRaised), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Air, null, tint = Accent)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(deviceName, color = Silver, fontWeight = FontWeight.SemiBold)
                    Text(brand.name, color = Muted, fontSize = 10.sp)
                    Text("Selected unit · Model profile not tested", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
            }
        }
        item {
            TemperatureCard(
                state = state,
                onPower = { update(state.copy(power = !state.power)) },
                onMinus = { update(state.copy(temperature = (state.temperature - 1).coerceAtLeast(if (state.celsius) 16 else 61))) },
                onPlus = { update(state.copy(temperature = (state.temperature + 1).coerceAtMost(if (state.celsius) 30 else 86))) },
                onUnit = {
                    val converted = if (state.celsius) (state.temperature * 9f / 5f + 32f).toInt() else ((state.temperature - 32) * 5f / 9f).toInt()
                    update(state.copy(celsius = !state.celsius, temperature = converted.coerceIn(if (state.celsius) 61 else 16, if (state.celsius) 86 else 30)))
                },
                onTemperature = { update(state.copy(temperature = it)) }
            )
        }
        item {
            SectionHeading("OPERATING MODE", "Choose how your AC should run")
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                AcMode.entries.forEach { mode -> ModeChip(mode, state.mode == mode) { update(state.copy(mode = mode)) } }
            }
        }
        item {
            SectionHeading("COMFORT", "Fine-tune your environment")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SettingTile("Fan speed", state.fan.label, Icons.Rounded.Air, Modifier.weight(1f)) {
                    update(state.copy(fan = FanSpeed.entries[(state.fan.ordinal + 1) % FanSpeed.entries.size]))
                }
                SettingTile("Swing", if (state.swing) "On" else "Off", Icons.Rounded.SwapVert, Modifier.weight(1f)) {
                    update(state.copy(swing = !state.swing))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureTile("Eco mode", state.eco, Icons.Rounded.EnergySavingsLeaf, Modifier.weight(1f)) { update(state.copy(eco = !state.eco)) }
                FeatureTile("Sleep mode", state.sleep, Icons.Rounded.Bedtime, Modifier.weight(1f)) { update(state.copy(sleep = !state.sleep)) }
            }
        }
        item {
            SectionHeading("QUICK ACTIONS", "Your everyday controls")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile("Sleep timer", if (timerMinutes == 0) "Off" else "${timerMinutes} min", Icons.Rounded.Timer, Modifier.weight(1f)) { showTimerDialog = true }
                ActionTile("Save preset", "Remember setup", Icons.Rounded.BookmarkAdd, Modifier.weight(1f)) { showSaveDialog = true }
            }
        }
        item {
            Button(onClick = onSend, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Rounded.Send, null); Spacer(Modifier.width(9.dp)); Text("Send settings to AC", fontWeight = FontWeight.Bold)
            }
        }
        item { StatusPanel(irStatus, notice) }
        item {
            Text(
                "Safety note: the interface remembers your settings, but it does not claim the AC received them. A matching model-specific IR profile must be tested against the physical AC before commands can be sent.",
                color = Muted, fontSize = 11.sp, lineHeight = 16.sp
            )
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save this setup") },
            text = { OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(24) }, label = { Text("Preset name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (presetName.isNotBlank()) onSaveFavorite(presetName.trim()); showSaveDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") } },
            containerColor = PanelRaised, titleContentColor = Silver, textContentColor = Silver
        )
    }
    if (showTimerDialog) {
        AlertDialog(
            onDismissRequest = { showTimerDialog = false },
            title = { Text("Sleep timer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (timerMinutes == 0) "No timer selected" else "Current selection: $timerMinutes minutes", color = Muted)
                    listOf(0, 30, 60, 90, 120, 240).forEach { value ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onTimer(value) }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (value == 0) "Off" else "$value minutes", modifier = Modifier.weight(1f))
                            if (timerMinutes == value) Icon(Icons.Rounded.Check, null, tint = Accent)
                        }
                    }
                    Text("A notification will remind you when the timer ends. Automatic AC shutdown is not enabled because this device has no verified AC command profile yet.", color = Muted, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showTimerDialog = false }) { Text("Done") } },
            containerColor = PanelRaised, titleContentColor = Silver, textContentColor = Silver
        )
    }
}

@Composable
private fun TemperatureCard(state: AcState, onPower: () -> Unit, onMinus: () -> Unit, onPlus: () -> Unit, onUnit: () -> Unit, onTemperature: (Int) -> Unit) {
    val scale by animateFloatAsState(if (state.power) 1f else .975f, spring(dampingRatio = .62f, stiffness = 420f), label = "power-scale")
    val accent by animateColorAsState(if (state.power) Accent else Muted, label = "power-accent")
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF273343), Color(0xFF171F2A), Color(0xFF10141B))))
            .padding(20.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("ACTIVE AC UNIT", color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp)
                    Text(if (state.power) "Comfort settings" else "Standby", color = Silver, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
                Surface(color = if (state.power) Color(0xFF1E3A34) else PanelRaised, shape = CircleShape) {
                    Text(if (state.power) "ON" else "OFF", Modifier.padding(horizontal = 13.dp, vertical = 7.dp), color = if (state.power) Good else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(22.dp))
            Box(
                Modifier.size(218.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF35465B), Color(0xFF202B39), Color(0xFF111720))))
                    .scale(scale), contentAlignment = Alignment.Center
            ) {
                TemperatureDial(state.temperature, state.celsius, onTemperature, Modifier.matchParentSize())
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TARGET TEMPERATURE", color = Muted, fontSize = 9.sp, letterSpacing = 1.35.sp)
                    Row(verticalAlignment = Alignment.Top) {
                        AnimatedContent(state.temperature, label = "temperature-value") { value ->
                            Text("$value", color = Silver, fontSize = 69.sp, fontWeight = FontWeight.Light, letterSpacing = (-4).sp)
                        }
                        Text("°", color = Accent, fontSize = 29.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    Text(state.mode.label.uppercase(), color = accent, fontSize = 10.sp, letterSpacing = 2.sp)
                    TextButton(onClick = onUnit, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Text(if (state.celsius) "SWITCH TO °F" else "SWITCH TO °C", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                }
            }
            Spacer(Modifier.height(15.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                RoundControl(Icons.Rounded.Remove, "Decrease temperature", onMinus)
                RoundControl(Icons.Rounded.Add, "Increase temperature", onPlus)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onPower, modifier = Modifier.fillMaxWidth().height(54.dp).scale(scale),
                shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (state.power) Color(0xFF34495E) else Accent, contentColor = if (state.power) Silver else Midnight)
            ) {
                Icon(Icons.Rounded.PowerSettingsNew, null); Spacer(Modifier.width(9.dp))
                Text(if (state.power) "Turn off AC" else "Turn on AC", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TemperatureDial(temperature: Int, celsius: Boolean, onTemperature: (Int) -> Unit, modifier: Modifier = Modifier) {
    val minTemp = if (celsius) 16 else 61
    val maxTemp = if (celsius) 30 else 86
    val progress = ((temperature - minTemp).toFloat() / (maxTemp - minTemp)).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(progress, spring(dampingRatio = .82f, stiffness = 240f), label = "dial-progress")

    fun updateFromOffset(position: Offset, width: Float, height: Float) {
        val dx = position.x - width / 2f
        val dy = position.y - height / 2f
        var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (angle < 0f) angle += 360f
        if (angle < 135f) angle += 360f
        val sweep = (angle - 135f).coerceIn(0f, 270f)
        val value = (minTemp + (sweep / 270f * (maxTemp - minTemp)).toInt()).coerceIn(minTemp, maxTemp)
        onTemperature(value)
    }

    Canvas(
        modifier = modifier
            .pointerInput(minTemp, maxTemp) {
                detectDragGestures(onDragStart = { updateFromOffset(it, size.width.toFloat(), size.height.toFloat()) }) { change, _ ->
                    updateFromOffset(change.position, size.width.toFloat(), size.height.toFloat())
                    change.consume()
                }
            }
            .pointerInput(minTemp, maxTemp) {
                detectTapGestures { updateFromOffset(it, size.width.toFloat(), size.height.toFloat()) }
            }
    ) {
        val stroke = 10.dp.toPx()
        val radius = size.minDimension / 2f - stroke / 2f - 5.dp.toPx()
        val arcSize = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f)
        val topLeft = Offset(center.x - radius, center.y - radius)
        drawArc(Color(0xFF536274).copy(alpha = .42f), 135f, 270f, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        drawArc(Accent.copy(alpha = .95f), 135f, 270f * animatedProgress, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        val angle = (135f + 270f * animatedProgress) * (PI / 180.0)
        val knob = Offset(center.x + radius * cos(angle).toFloat(), center.y + radius * sin(angle).toFloat())
        drawCircle(Color(0xFF090B0F).copy(alpha = .75f), radius = 9.dp.toPx(), center = knob)
        drawCircle(Accent, radius = 6.dp.toPx(), center = knob)
    }
}

@Composable
private fun SectionHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
        Text(subtitle, color = Silver, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun RoundControl(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(48.dp).clip(CircleShape).background(PanelRaised)) {
        Icon(icon, description, tint = Silver, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun ModeChip(mode: AcMode, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Color(0xFF26394D) else Panel, label = "mode-chip")
    Surface(onClick = onClick, shape = RoundedCornerShape(14.dp), color = bg, border = if (selected) BorderStroke(1.dp, Accent.copy(alpha = .35f)) else null) {
        Column(Modifier.width(58.dp).padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(when (mode) {
                AcMode.COOL -> Icons.Rounded.AcUnit; AcMode.HEAT -> Icons.Rounded.WbSunny
                AcMode.AUTO -> Icons.Rounded.AutoMode; AcMode.DRY -> Icons.Rounded.WaterDrop; AcMode.FAN -> Icons.Rounded.Air
            }, null, tint = if (selected) Accent else Muted, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(6.dp)); Text(mode.label, fontSize = 10.sp, color = if (selected) Silver else Muted)
        }
    }
}

@Composable
private fun SettingTile(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(17.dp)).background(Panel).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) { Text(title, color = Muted, fontSize = 10.sp); Text(value, color = Silver, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        Icon(Icons.Rounded.ChevronRight, null, tint = Muted, modifier = Modifier.size(17.dp))
    }
}

@Composable
private fun FeatureTile(title: String, enabled: Boolean, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(16.dp)).background(if (enabled) Color(0xFF203344) else Panel).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (enabled) Accent else Muted); Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) { Text(title, color = Silver, fontSize = 12.sp, fontWeight = FontWeight.Medium); Text(if (enabled) "Enabled locally" else "Off", color = Muted, fontSize = 10.sp) }
        Icon(if (enabled) Icons.Rounded.ToggleOn else Icons.Rounded.ToggleOff, null, tint = if (enabled) Accent else Muted, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) { Text(title, color = Silver, fontSize = 12.sp, fontWeight = FontWeight.Medium); Text(subtitle, color = Muted, fontSize = 10.sp) }
        Icon(Icons.Rounded.ChevronRight, null, tint = Muted, modifier = Modifier.size(17.dp))
    }
}

@Composable
private fun StatusPanel(status: IrStatus, notice: String) {
    val title = when (status) { IrStatus.Ready -> "IR hardware detected"; IrStatus.NoEmitter -> "No IR blaster detected"; IrStatus.UnsupportedFrequency -> "IR frequency unavailable"; is IrStatus.Failed -> "IR hardware issue" }
    val detail = when (status) { IrStatus.Ready -> "Your phone reports an infrared transmitter. A verified AC profile is still needed."; IrStatus.NoEmitter -> "This phone cannot transmit infrared directly. A compatible external IR accessory may be needed."; IrStatus.UnsupportedFrequency -> "The phone did not report a usable carrier-frequency range."; is IrStatus.Failed -> status.reason }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.Top) {
        Icon(if (status == IrStatus.Ready) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = if (status == IrStatus.Ready) Good else Accent)
        Spacer(Modifier.width(11.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = Silver, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(detail, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            Text(notice, color = Accent, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun DevicesScreen(
    devices: List<AcDevice>, profiles: List<ImportedIrProfile>, selectedDeviceId: String,
    onSelect: (AcDevice) -> Unit, onAdd: (String) -> Unit,
    onRename: (AcDevice, String) -> Unit, onDelete: (AcDevice) -> Unit,
    onBrand: (AcDevice, String) -> Unit, onProfile: (AcDevice, String?) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<AcDevice?>(null) }
    var draftName by remember { mutableStateOf("") }
    var brandMenuFor by remember { mutableStateOf<String?>(null) }
    var profileMenuFor by remember { mutableStateOf<String?>(null) }
    val filtered = remember(query) { BrandCatalog.brands.filter { it.name.contains(query.trim(), ignoreCase = true) } }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("YOUR DEVICES", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Text("Device library", color = Silver, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
            Text("Manage separate AC units and their individual settings.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(8.dp)); Text("Add AC device")
            }
        }
        item { SectionHeading("SAVED UNITS", "Each device keeps its own settings") }
        items(devices, key = { it.id }) { device ->
            val brandName = BrandCatalog.brands.firstOrNull { it.id == device.brandId }?.name ?: "Other / custom"
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (device.id == selectedDeviceId) Color(0xFF202F40) else Panel).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(PanelRaised), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.AcUnit, null, tint = Accent)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(device.name, color = Silver, fontWeight = FontWeight.SemiBold)
                        Text("$brandName · ${device.state.temperature}°${if (device.state.celsius) "C" else "F"}", color = Muted, fontSize = 10.sp)
                    }
                    if (device.id == selectedDeviceId) Text("ACTIVE", color = Good, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    else TextButton(onClick = { onSelect(device) }) { Text("Select") }
                }
                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(onClick = { brandMenuFor = device.id }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Change brand", fontSize = 11.sp) }
                    OutlinedButton(onClick = { profileMenuFor = device.id }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text(if (device.profileId == null) "Assign profile" else "Change profile", fontSize = 11.sp) }
                    OutlinedButton(onClick = { editing = device; draftName = device.name }, contentPadding = PaddingValues(horizontal = 8.dp)) { Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(15.dp)); Text("Rename", fontSize = 11.sp) }
                    IconButton(onClick = { onDelete(device) }, enabled = devices.size > 1) { Icon(Icons.Rounded.DeleteOutline, "Delete device", tint = if (devices.size > 1) Muted else Muted.copy(alpha = .35f)) }
                }
                DropdownMenu(expanded = brandMenuFor == device.id, onDismissRequest = { brandMenuFor = null }, modifier = Modifier.heightIn(max = 360.dp).background(PanelRaised)) {
                    BrandCatalog.brands.forEach { brand ->
                        DropdownMenuItem(text = { Text(brand.name) }, onClick = { onBrand(device, brand.id); brandMenuFor = null })
                    }
                }
                DropdownMenu(expanded = profileMenuFor == device.id, onDismissRequest = { profileMenuFor = null }, modifier = Modifier.heightIn(max = 360.dp).background(PanelRaised)) {
                    DropdownMenuItem(text = { Text("No profile") }, onClick = { onProfile(device, null); profileMenuFor = null })
                    profiles.filter { it.brandId == device.brandId && it.userConfirmed }.forEach { profile ->
                        DropdownMenuItem(text = { Text(profile.modelLabel) }, onClick = { onProfile(device, profile.id); profileMenuFor = null })
                    }
                    if (profiles.none { it.brandId == device.brandId && it.userConfirmed }) {
                        DropdownMenuItem(text = { Text("No tested profiles for this brand") }, enabled = false, onClick = { })
                    }
                }
            }
        }
        item {
            SectionHeading("BRAND DIRECTORY", "O General is prioritised; more profiles can be added")
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search brands") }, leadingIcon = { Icon(Icons.Rounded.Search, null) }, singleLine = true, shape = RoundedCornerShape(15.dp))
        }
        items(filtered, key = { "brand-${it.id}" }) { brand ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Panel).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(brand.name, color = Silver, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                Text(if (brand.isPriority) "PRIORITY" else "AVAILABLE", color = if (brand.isPriority) Accent else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Text("Protocol compatibility", color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("A brand selection is not an IR profile. AC models may use different full-state protocols. This app only reports transmission as successful when Android accepts a supplied frame; the AC itself must still be tested.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
    if (showAdd) {
        var name by remember { mutableStateOf("Bedroom AC") }
        AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Add AC device") },
            text = { OutlinedTextField(name, { name = it.take(32) }, label = { Text("Device name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onAdd(name.trim()); showAdd = false }) { Text("Add") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } },
            containerColor = PanelRaised, titleContentColor = Silver, textContentColor = Silver)
    }
    editing?.let { device ->
        AlertDialog(onDismissRequest = { editing = null }, title = { Text("Rename device") },
            text = { OutlinedTextField(draftName, { draftName = it.take(32) }, label = { Text("Device name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (draftName.isNotBlank()) onRename(device, draftName.trim()); editing = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } },
            containerColor = PanelRaised, titleContentColor = Silver, textContentColor = Silver)
    }
}

@Composable
private fun ProfilesScreen(
    profiles: List<ImportedIrProfile>, testedProfileIds: Set<String>, onImport: () -> Unit,
    onTest: (ImportedIrProfile) -> Unit, onConfirm: (ImportedIrProfile) -> Unit, onDelete: (ImportedIrProfile) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("UNIVERSAL IR", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Text("IR profiles", color = Silver, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
            Text("Import model-specific raw state frames. No brand codes are fabricated or guessed.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(7.dp))
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Rounded.FileOpen, null); Spacer(Modifier.width(8.dp)); Text("Import IR profile JSON")
            }
        }
        if (profiles.isEmpty()) item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(22.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Dataset, null, tint = Accent, modifier = Modifier.size(32.dp))
                    Text("No IR profiles imported", color = Silver, fontWeight = FontWeight.SemiBold)
                    Text("Add a profile captured from a compatible IR learning device or prepared from verified protocol data.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
        items(profiles, key = { it.id }) { profile ->
            val brand = BrandCatalog.brands.firstOrNull { it.id == profile.brandId }?.name ?: profile.brandId
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Panel).padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(profile.modelLabel, color = Silver, fontWeight = FontWeight.SemiBold)
                        Text("$brand · ${profile.carrierFrequencyHz / 1000} kHz · ${profile.frames.size} state frames", color = Muted, fontSize = 10.sp)
                    }
                    Text(if (profile.userConfirmed) "USER-TESTED" else "UNTESTED", color = if (profile.userConfirmed) Good else Accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onTest(profile) }, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.Waves, null); Spacer(Modifier.width(5.dp)); Text("Test first frame", fontSize = 10.sp) }
                    IconButton(onClick = { onDelete(profile) }) { Icon(Icons.Rounded.DeleteOutline, "Delete profile", tint = Muted) }
                }
                if (!profile.userConfirmed && profile.id in testedProfileIds) {
                    Text("Android accepted the test transmission. Only confirm if the actual AC responded correctly.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    Button(onClick = { onConfirm(profile) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("AC responded — confirm profile") }
                }
                if (profile.userConfirmed) Text("This profile can be assigned to matching devices. Only exact states included in its imported frames can be sent.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        item {
            Text("Profile JSON format", color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("Schema v1 requires brandId, modelLabel, carrierFrequencyHz and a commands array. Each command contains a complete state plus alternating mark/space durationsMicros. Importing never marks a profile tested. The app requires you to test it on the physical AC and confirm its response.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun FavoritesScreen(favorites: List<FavoritePreset>, onApply: (AcState) -> Unit, onDelete: (FavoritePreset) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 22.dp)) {
        Text("YOUR SHORTCUTS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Text("Saved presets", color = Silver, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp)); Text("Save a favourite setup from the Remote screen for quick access.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        if (favorites.isEmpty()) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(25.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Rounded.BookmarkBorder, null, tint = Accent, modifier = Modifier.size(34.dp))
                    Text("No presets yet", color = Silver, fontWeight = FontWeight.SemiBold)
                    Text("Create one from your current remote settings.", color = Muted, fontSize = 11.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(favorites, key = { it.name + it.hashCode() }) { favorite ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bookmark, null, tint = Accent)
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(favorite.name, color = Silver, fontWeight = FontWeight.SemiBold)
                            Text("${favorite.state.temperature}°${if (favorite.state.celsius) "C" else "F"} · ${favorite.state.mode.label} · ${favorite.state.fan.label} fan", color = Muted, fontSize = 10.sp)
                        }
                        IconButton(onClick = { onApply(favorite.state) }) { Icon(Icons.Rounded.PlayArrow, "Apply preset", tint = Accent) }
                        IconButton(onClick = { onDelete(favorite) }) { Icon(Icons.Rounded.DeleteOutline, "Delete preset", tint = Muted) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(status: IrStatus, ranges: List<android.hardware.ConsumerIrManager.CarrierFrequencyRange>) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("PREFERENCES", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Text("Settings", color = Silver, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        }
        item { InfoRow("Infrared hardware", when (status) { IrStatus.Ready -> "Available"; IrStatus.NoEmitter -> "Not detected"; IrStatus.UnsupportedFrequency -> "No supported range"; is IrStatus.Failed -> "Error" }) }
        item { InfoRow("Carrier frequency ranges", if (ranges.isEmpty()) "Unavailable" else "${ranges.size} reported range(s)") }
        item { InfoRow("Primary brand", "O General") }
        item { InfoRow("Architecture", "Kotlin · Jetpack Compose") }
        item { InfoRow("App version", "0.3.0 · Multi-device") }
        item {
            Text("IR compatibility", color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("A phone needs a built-in IR emitter to control an AC directly. Many Android phones do not have one. The app intentionally contains no guessed O General codes: a model-specific profile must be captured from a working remote or verified against trustworthy protocol documentation and tested on the actual unit.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        item {
            Text("Privacy", color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("Your remote settings, selected brand and presets are stored locally on this device. This build does not require an account.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, modifier = Modifier.weight(1f), fontSize = 12.sp)
        Text(value, color = Silver, fontWeight = FontWeight.Medium, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
