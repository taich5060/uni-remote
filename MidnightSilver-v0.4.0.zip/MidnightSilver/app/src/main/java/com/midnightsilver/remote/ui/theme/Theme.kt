package com.midnightsilver.remote.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Midnight = Color(0xFF090B0F)
val Panel = Color(0xFF141820)
val PanelRaised = Color(0xFF1C222C)
val Silver = Color(0xFFD9E0E9)
val Muted = Color(0xFF8994A4)
val Accent = Color(0xFF9CCBFF)
val AccentDeep = Color(0xFF456D96)
val Good = Color(0xFF8ED6B0)

private val Scheme = darkColorScheme(
    primary = Accent, onPrimary = Midnight, secondary = Silver, onSecondary = Midnight,
    background = Midnight, onBackground = Silver, surface = Panel, onSurface = Silver,
    surfaceVariant = PanelRaised, onSurfaceVariant = Muted, outline = Color(0xFF303946)
)

@Composable fun MidnightSilverTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
