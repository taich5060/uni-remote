package com.midnightsilver.remote.data

enum class AcMode(val label: String) { COOL("Cool"), HEAT("Heat"), AUTO("Auto"), DRY("Dry"), FAN("Fan") }
enum class FanSpeed(val label: String) { AUTO("Auto"), LOW("Low"), MEDIUM("Medium"), HIGH("High") }

data class AcState(
    val power: Boolean = false,
    val temperature: Int = 24,
    val mode: AcMode = AcMode.COOL,
    val fan: FanSpeed = FanSpeed.AUTO,
    val swing: Boolean = false,
    val celsius: Boolean = true,
    val sleep: Boolean = false,
    val eco: Boolean = false
)

data class AcBrand(val id: String, val name: String, val isPriority: Boolean = false)

data class IrProfile(
    val id: String,
    val brandId: String,
    val modelLabel: String,
    val protocolName: String,
    val carrierFrequencyHz: Int,
    val verified: Boolean,
    val notes: String
)

data class FavoritePreset(val name: String, val state: AcState)

object BrandCatalog {
    val brands = listOf(
        AcBrand("ogeneral", "O General", true), AcBrand("daikin", "Daikin"),
        AcBrand("voltas", "Voltas"), AcBrand("lg", "LG"), AcBrand("samsung", "Samsung"),
        AcBrand("panasonic", "Panasonic"), AcBrand("hitachi", "Hitachi"),
        AcBrand("blue_star", "Blue Star"), AcBrand("carrier", "Carrier"),
        AcBrand("mitsubishi", "Mitsubishi Electric"), AcBrand("haier", "Haier"),
        AcBrand("whirlpool", "Whirlpool"), AcBrand("other", "Other / custom")
    )

    // No command data is claimed as verified until tested against a physical AC.
    val profiles: List<IrProfile> = emptyList()
}
