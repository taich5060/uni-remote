package com.midnightsilver.remote.ir

import android.content.Context
import android.hardware.ConsumerIrManager

sealed interface IrStatus {
    data object Ready : IrStatus
    data object NoEmitter : IrStatus
    data object UnsupportedFrequency : IrStatus
    data class Failed(val reason: String) : IrStatus
}

class IrTransmitter(context: Context) {
    private val manager = context.applicationContext.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    fun status(): IrStatus = when {
        manager == null -> IrStatus.NoEmitter
        !manager.hasIrEmitter() -> IrStatus.NoEmitter
        manager.carrierFrequencies.isNullOrEmpty() -> IrStatus.UnsupportedFrequency
        else -> IrStatus.Ready
    }

    fun supportedCarrierRanges(): List<ConsumerIrManager.CarrierFrequencyRange> =
        manager?.carrierFrequencies?.toList().orEmpty()

    /** Transmits only a supplied, externally verified raw frame. Never guesses AC command data. */
    fun transmit(carrierHz: Int, patternMicros: IntArray): IrStatus {
        val ir = manager ?: return IrStatus.NoEmitter
        if (!ir.hasIrEmitter()) return IrStatus.NoEmitter
        if (carrierHz !in 30_000..60_000) return IrStatus.Failed("Carrier frequency is outside the supported AC profile range.")
        if (patternMicros.size !in 2..2048 || patternMicros.size % 2 != 0 || patternMicros.any { it !in 1..100_000 }) {
            return IrStatus.Failed("IR frame must contain 2–2048 positive alternating mark/space durations.")
        }
        if (patternMicros.sumOf { it.toLong() } > 1_000_000L) {
            return IrStatus.Failed("IR frame exceeds the 1-second safety limit.")
        }
        val supported = ir.carrierFrequencies?.any { carrierHz in it.minFrequency..it.maxFrequency } == true
        if (!supported) return IrStatus.UnsupportedFrequency
        return try {
            ir.transmit(carrierHz, patternMicros.copyOf())
            IrStatus.Ready
        } catch (e: SecurityException) {
            IrStatus.Failed("Android denied access to the IR transmitter.")
        } catch (e: IllegalArgumentException) {
            IrStatus.Failed(e.message ?: "The IR frame is not accepted by this device.")
        } catch (e: Exception) {
            IrStatus.Failed(e.message ?: "IR transmission failed.")
        }
    }
}
