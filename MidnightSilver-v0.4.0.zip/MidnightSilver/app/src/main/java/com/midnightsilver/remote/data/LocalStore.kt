package com.midnightsilver.remote.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small local preference store. It deliberately stores user settings, not fabricated IR codes. */
class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("midnight_silver", Context.MODE_PRIVATE)

    fun loadBrand(): String = prefs.getString("brand", "ogeneral") ?: "ogeneral"
    fun saveBrand(id: String) { prefs.edit().putString("brand", id).apply() }

    fun saveTimerDeadline(deviceId: String, deadlineMillis: Long?) {
        prefs.edit().apply {
            if (deadlineMillis == null) remove("sleep_timer_$deviceId") else putLong("sleep_timer_$deviceId", deadlineMillis)
        }.apply()
    }

    fun loadTimerRemainingMinutes(deviceId: String): Int {
        val deadline = prefs.getLong("sleep_timer_$deviceId", 0L)
        if (deadline <= 0L) return 0
        val remaining = deadline - System.currentTimeMillis()
        if (remaining <= 0L) {
            saveTimerDeadline(deviceId, null)
            return 0
        }
        return ((remaining + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
    }

    fun loadDevices(): List<AcDevice> {
        val raw = prefs.getString("devices", null)
        if (raw.isNullOrBlank()) {
            val legacy = AcDevice(name = "Living room AC", brandId = loadBrand(), state = loadState())
            saveDevices(listOf(legacy))
            return listOf(legacy)
        }
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val devices = buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val stateJson = runCatching { item.optJSONObject("state") ?: JSONObject() }.getOrDefault(JSONObject())
                add(AcDevice(
                    id = item.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
                    name = item.optString("name", "AC unit").ifBlank { "AC unit" }.take(32),
                    brandId = item.optString("brandId", "ogeneral").ifBlank { "ogeneral" },
                    state = stateFromJson(stateJson),
                    profileId = item.opt("profileId")?.takeIf { it != JSONObject.NULL }?.toString()?.takeIf { it.isNotBlank() && it != "null" }
                ))
            }
        }
        return devices.ifEmpty { listOf(DeviceDefaults.primary()) }
    }

    fun saveDevices(devices: List<AcDevice>) {
        val array = JSONArray()
        devices.forEach { device ->
            array.put(JSONObject().apply {
                put("id", device.id); put("name", device.name); put("brandId", device.brandId)
                put("profileId", device.profileId ?: JSONObject.NULL)
                put("state", stateToJson(device.state))
            })
        }
        prefs.edit().putString("devices", array.toString()).apply()
    }

    fun loadImportedProfiles(): List<ImportedIrProfile> {
        val array = runCatching { JSONArray(prefs.getString("ir_profiles", "[]") ?: "[]") }.getOrDefault(JSONArray())
        return buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val parsed = runCatching { ImportedIrProfile.parse(item.toString()) }.getOrNull() ?: continue
                add(parsed.copy(userConfirmed = item.optBoolean("userConfirmed", false)))
            }
        }
    }

    fun saveImportedProfiles(profiles: List<ImportedIrProfile>) {
        val array = JSONArray()
        profiles.forEach { profile ->
            array.put(profile.toJson().put("userConfirmed", profile.userConfirmed))
        }
        prefs.edit().putString("ir_profiles", array.toString()).apply()
    }

    private fun stateFromJson(json: JSONObject): AcState {
        val celsius = json.optBoolean("celsius", true)
        return AcState(
            power = json.optBoolean("power", false),
            temperature = json.optInt("temperature", if (celsius) 24 else 75).coerceIn(if (celsius) 16 else 61, if (celsius) 30 else 86),
            mode = runCatching { AcMode.valueOf(json.optString("mode", "COOL")) }.getOrDefault(AcMode.COOL),
            fan = runCatching { FanSpeed.valueOf(json.optString("fan", "AUTO")) }.getOrDefault(FanSpeed.AUTO),
            swing = json.optBoolean("swing", false), celsius = celsius,
            sleep = json.optBoolean("sleep", false), eco = json.optBoolean("eco", false)
        )
    }

    private fun stateToJson(state: AcState) = JSONObject().apply {
        put("power", state.power); put("temperature", state.temperature); put("mode", state.mode.name)
        put("fan", state.fan.name); put("swing", state.swing); put("celsius", state.celsius)
        put("sleep", state.sleep); put("eco", state.eco)
    }

    fun loadState(): AcState {
        val json = runCatching { JSONObject(prefs.getString("state", "{}") ?: "{}") }.getOrDefault(JSONObject())
        return stateFromJson(json)
    }

    fun saveState(state: AcState) {
        val json = JSONObject().apply {
            put("power", state.power); put("temperature", state.temperature); put("mode", state.mode.name)
            put("fan", state.fan.name); put("swing", state.swing); put("celsius", state.celsius)
            put("sleep", state.sleep); put("eco", state.eco)
        }
        prefs.edit().putString("state", json.toString()).apply()
    }

    fun loadFavorites(): List<FavoritePreset> {
        val array = runCatching { JSONArray(prefs.getString("favorites", "[]") ?: "[]") }.getOrDefault(JSONArray())
        return buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val state = runCatching { JSONObject(item.optString("state", "{}")) }.getOrDefault(JSONObject())
                add(FavoritePreset(item.optString("name", "Favorite"), stateFromJson(state)))
            }
        }
    }

    fun saveFavorites(favorites: List<FavoritePreset>) {
        val array = JSONArray()
        favorites.forEach { favorite ->
            val state = favorite.state
            val stateJson = JSONObject().apply {
                put("power", state.power); put("temperature", state.temperature); put("mode", state.mode.name)
                put("fan", state.fan.name); put("swing", state.swing); put("celsius", state.celsius)
                put("sleep", state.sleep); put("eco", state.eco)
            }
            array.put(JSONObject().put("name", favorite.name).put("state", stateJson.toString()))
        }
        prefs.edit().putString("favorites", array.toString()).apply()
    }
}
