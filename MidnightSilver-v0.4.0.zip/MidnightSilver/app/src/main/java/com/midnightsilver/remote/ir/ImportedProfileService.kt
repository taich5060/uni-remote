package com.midnightsilver.remote.ir

import com.midnightsilver.remote.data.AcState
import com.midnightsilver.remote.data.ImportedIrProfile

sealed interface ProfileSendResult {
    data object NoProfile : ProfileSendResult
    data object ProfileNotConfirmed : ProfileSendResult
    data object StateNotIncluded : ProfileSendResult
    data class Sent(val status: IrStatus) : ProfileSendResult
}

class ImportedProfileService(private val transmitter: IrTransmitter) {
    fun send(state: AcState, profile: ImportedIrProfile?): ProfileSendResult {
        if (profile == null) return ProfileSendResult.NoProfile
        if (!profile.userConfirmed) return ProfileSendResult.ProfileNotConfirmed
        val frame = profile.frames.firstOrNull { it.state == state } ?: return ProfileSendResult.StateNotIncluded
        return ProfileSendResult.Sent(transmitter.transmit(profile.carrierFrequencyHz, frame.durationsMicros.toIntArray()))
    }

    /** Sends one frame as a user-requested test; transmission acceptance is not proof the AC responded. */
    fun test(profile: ImportedIrProfile?): IrStatus? {
        if (profile == null) return null
        val frame = profile.frames.first()
        return transmitter.transmit(profile.carrierFrequencyHz, frame.durationsMicros.toIntArray())
    }
}
