# Midnight Silver — current engineering brief (v0.4.0)

Continue from this codebase; do not replace it with a new template or remove existing features.

## Product direction
- Native Android Kotlin + Jetpack Compose app.
- Premium Midnight Silver dark visual identity.
- O General is the first-priority brand; architecture is universal and model-profile driven.
- Maintain smooth, restrained motion and fast interactions.

## Current implementation
- Remote UI with temperature, unit, mode, fan, swing, Eco, Sleep, favourites and explicit Send Settings action.
- Multiple named AC devices with per-device brand, state and imported-profile assignment.
- Local persistence for devices, favourites and imported profiles.
- WorkManager sleep reminder notifications. This is deliberately a reminder, not automatic shutdown.
- ConsumerIrManager detection and raw-frame transmission with defensive limits.
- Schema-v1 JSON importer for complete-state raw IR frames.
- Imported profiles are untrusted until the user tests a frame and explicitly confirms the physical AC responded.
- The sender matches exact AcState entries only; it never invents missing frames or interpolates temperatures.
- Parser unit tests and a GitHub Actions debug APK workflow.

## Critical IR truth
There are no fabricated O General codes in this project. The user's exact AC model/remote is unknown. Do not invent pulse timings or label a profile verified because Android accepted transmission. Actual O General control requires model-compatible raw timings captured from a learning receiver or implemented from trustworthy protocol data, then tested on the physical unit.

## Next engineering tasks
1. Run Gradle sync and `:app:testDebugUnitTest` using JDK 17 and Android SDK 35; fix every compile/test failure.
2. Build and install debug APK on an IR-equipped Android phone.
3. Validate a real O General profile against the user's actual unit when source timings are available.
4. Improve profile import/export, exact-state coverage feedback, and profile matching diagnostics.
5. Add persistent timer countdown display and restore timer status from WorkManager.
6. Add accessibility, TalkBack descriptions, large-font layout checks and reduced-motion handling.
7. Profile animations on 60 Hz and 120 Hz devices; fix jank before claiming frame-rate targets.

Do not claim APK compilation, physical IR compatibility, or 60/120 FPS testing unless actually performed.
