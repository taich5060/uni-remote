# Midnight Silver IR profile format (schema v1)

Midnight Silver intentionally ships without guessed O General timings. AC remotes commonly send a complete state frame, and timings vary by model. A profile must come from a compatible IR-learning receiver or trustworthy protocol implementation and must be tested against the physical AC.

## Required JSON fields

- `schemaVersion`: integer `1`
- `brandId`: catalog id such as `ogeneral`, `daikin`, `voltas`, `lg`, `samsung`, `panasonic`, `hitachi`, `blue_star`, `carrier`, `mitsubishi`, `haier`, `whirlpool`, or `other`
- `modelLabel`: human-readable model family or remote identifier
- `carrierFrequencyHz`: integer from 30000 to 60000
- `commands`: 1–100 complete state frames

Each command contains:

- `state`: `power`, `temperature`, `celsius`, `mode`, `fan`, `swing`, `eco`, and `sleep`
- `durationsMicros`: even-length array of alternating mark/space durations in microseconds (2–2048 entries, each 1–100000; total frame duration at most 1 second)

Temperature must be 16–30 for Celsius or 61–86 for Fahrenheit. `mode` is one of `COOL`, `HEAT`, `AUTO`, `DRY`, `FAN`; `fan` is one of `AUTO`, `LOW`, `MEDIUM`, `HIGH`.

## Important behaviour

1. Importing a file never marks it as tested, regardless of any `verified` field in the file.
2. The first frame is used for the explicit test action. Put a safe, known test state first.
3. The app can only report that Android accepted a transmission. It cannot receive confirmation from a typical phone IR blaster.
4. Only after observing the physical AC respond should the user mark the profile as user-tested.
5. The app sends only exact `AcState` combinations present in the profile. It does not interpolate or invent missing temperatures/modes.
6. Carrier frequency must also fall inside the phone's reported Consumer IR carrier range.

Never populate this format with guessed pulse timings. A wrong full-state frame can change the AC to an unintended setting; test carefully and keep the original remote available.
