# O General / Fujitsu protocol research

Research date: 2026-11-11

## Confirmed public compatibility lead

The current IRremoteESP8266 supported-protocol table lists:

- Brand: OGeneral
- Remote: AR-RCL1E
- Protocol family: Fujitsu AC
- Fujitsu remote-model variant: ARRAH2E

Reference: https://github.com/crankyoldgit/IRremoteESP8266/blob/master/SupportedProtocols.md

The Fujitsu implementation header independently lists the OGeneral AR-RCL1E remote as ARRAH2E:

https://github.com/crankyoldgit/IRremoteESP8266/blob/master/src/ir_Fujitsu.h

## Compatibility warning

The Fujitsu implementation explicitly warns that using the wrong model variant can cause an AC to lock up. It gives an example where an AR-RAH1U remote should use ARREB1E, not ARRAH2E, when using swing commands.

Because the user's exact AC and remote model are unknown, this project must not silently select ARRAH2E for every O General unit. The AR-RCL1E listing is a useful lead, not proof that every O General unit is compatible.

## Implementation notes

The referenced Fujitsu implementation uses a 38 kHz carrier and a mark/space protocol. It supports several distinct remote variants with different frame lengths, field encodings, and checksums. It also notes that some features are model-specific. Do not claim compatibility for unsupported modes or features.

Android ConsumerIrManager reports whether an emitter exists, reports supported carrier ranges, and transmits an alternating mark/space pattern synchronously. Android documents a maximum pattern duration below 2 seconds. Midnight Silver currently applies stricter import limits.

Android API reference: https://developer.android.com/reference/android/hardware/ConsumerIrManager

## Next step before native O General encoder activation

1. Identify the original O General remote model (AR-RCL1E or another model family) from the label on the remote or its manual.
2. Confirm the AC model/series if available.
3. Implement only the exact matching Fujitsu variant.
4. Add deterministic byte-frame and pulse-timing unit tests against public reference vectors.
5. Keep the native profile marked as a candidate until the actual AC responds correctly in a physical test.

Do not test arbitrary Fujitsu variants by cycling through them on the AC. A mismatch may cause unexpected behaviour or require a power reset.
