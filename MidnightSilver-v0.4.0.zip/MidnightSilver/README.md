# Midnight Silver AC Remote — v0.4.0

A native Android AC remote built with Kotlin and Jetpack Compose. O General is the priority brand; the architecture supports additional brands and model-specific imported profiles.

## What's implemented

- Midnight Silver dark UI with Compose transitions, an animated temperature arc and tap/drag temperature control.
- Remote state controls: power, temperature, Celsius/Fahrenheit, mode, fan, swing, Eco and Sleep.
- Multiple named AC devices, each with its own brand, profile assignment and independent settings.
- Local persistence for devices, state, favourites and imported IR profiles.
- Preset save/apply/delete flows.
- Sleep reminder scheduled with WorkManager; it posts a reminder and does not falsely claim to switch off the AC.
- Consumer IR hardware detection and supported carrier-frequency reporting.
- Defensive raw-frame validation and actual IR transmission through Android `ConsumerIrManager`.
- Universal imported IR profile workflow using schema v1 JSON.
- Exact-state matching: the app sends only a complete state frame included in the assigned profile.
- Explicit test and user-confirmation workflow. Imported files are never automatically trusted as verified.
- Unit tests for profile parsing and invalid profile rejection.
- Research notes documenting the O General AR-RCL1E / Fujitsu ARRAH2E compatibility lead and model-mismatch warning.
- GitHub Actions workflow for producing a debug APK after the project is pushed to GitHub.

## Build locally

Requirements: JDK 17, Android SDK with API 35, and Gradle 8.11.1 or compatible.

1. Open the `MidnightSilver` folder in Android Studio.
2. Allow Gradle sync and install any requested SDK components.
3. Run the unit tests with `gradle :app:testDebugUnitTest`.
4. Build with `gradle :app:assembleDebug`.
5. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

The included GitHub Actions workflow can also build the debug APK. Push the project to a GitHub repository and run the `Android debug build` workflow; download the `midnight-silver-debug-apk` artifact.

## IR compatibility — honest limitations

A phone needs a built-in Consumer IR emitter to control an AC directly. Many Android phones do not have one. This source project does not contain guessed O General pulse timings because the AC model/remote is unknown and a wrong full-state frame may be incompatible.

To enable a device:

1. Obtain complete-state raw timings from a compatible IR learning receiver or verified protocol implementation for the exact model/remote family.
2. Convert them to the schema described in `docs/IR_PROFILE_FORMAT.md`.
3. Import the JSON in the app's **IR Profiles** tab.
4. Test the first frame against the physical AC.
5. Only after observing a correct response, mark the profile as user-tested.
6. Assign that profile to the matching device.

Only exact states included in the imported profile can be transmitted. The app does not invent missing temperature/mode combinations. Android accepting a transmission does not prove that the AC received it.

## Sleep timer

The sleep timer is a WorkManager-backed notification reminder. Automatic shutdown is intentionally not claimed until a reliable, tested power-off frame is available and assigned. Android notification permission must be granted for the reminder to appear.

## Privacy

Device names, brands, state, favourites and imported profile data are stored locally using app preferences. No account or network permission is required by the app.
